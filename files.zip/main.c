/**
 * @file main.c
 * @brief Point d'entrée du simulateur d'ordonnancement.
 *
 * Usage :
 *   ./scheduler <fichier_processus.txt>
 *
 * Format du fichier d'entrée :
 *   PID  arrival_time  cpu1  [io1  cpu2  [io2  cpu3 ...]]
 *
 * Les cycles s'alternent : CPU io CPU io ... CPU
 * Le dernier CPU peut ne pas avoir d'E/S.
 *
 * Exemples :
 *   1  0  8              → 1 cycle CPU seul
 *   2  1  4  2  3        → CPU=4, E/S=2, CPU=3
 *   3  2  4  2  3  1  2  → CPU=4, E/S=2, CPU=3, E/S=1, CPU=2
 *
 * Les lignes commençant par '#' sont ignorées.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "process.h"
#include "fifo.h"
#include "metrics.h"

/**
 * @brief Charge les processus depuis un fichier texte multi-cycles.
 *
 * Chaque ligne : PID arrival cpu1 [io1 [cpu2 [io2 [...]]]]
 * Les valeurs alternent CPU et E/S. Si le nombre de valeurs est impair,
 * le dernier E/S vaut 0 (pas d'E/S après le dernier cycle CPU).
 *
 * @param filename   Chemin du fichier
 * @param processes  Tableau à remplir
 * @return           Nombre de processus lus, -1 si erreur
 */
static int load_processes(const char *filename, Process processes[])
{
    FILE *f = fopen(filename, "r");
    if (!f) { perror("Erreur ouverture fichier"); return -1; }

    int  n = 0;
    char line[512];

    while (fgets(line, sizeof(line), f) && n < MAX_PROCESSES) {

        /* Ignorer commentaires et lignes vides */
        if (line[0] == '#' || line[0] == '\n') continue;

        Process p;
        memset(&p, 0, sizeof(Process));

        /* Lire PID et arrival_time */
        char *tok = strtok(line, " \t\n");
        if (!tok) continue;
        p.pid = atoi(tok);

        tok = strtok(NULL, " \t\n");
        if (!tok) continue;
        p.arrival_time = atoi(tok);

        /*
         * Lire les cycles alternés CPU / E/S :
         *   valeurs[0] = cpu_bursts[0]
         *   valeurs[1] = io_bursts[0]
         *   valeurs[2] = cpu_bursts[1]
         *   valeurs[3] = io_bursts[1]
         *   ...
         */
        int vals[MAX_CYCLES * 2];
        int nb_vals = 0;

        while ((tok = strtok(NULL, " \t\n")) && nb_vals < MAX_CYCLES * 2)
            vals[nb_vals++] = atoi(tok);

        /* Convertir en tableaux cpu_bursts / io_bursts */
        p.nb_cycles = 0;
        for (int v = 0; v < nb_vals && p.nb_cycles < MAX_CYCLES; v += 2) {
            p.cpu_bursts[p.nb_cycles] = vals[v];
            p.io_bursts[p.nb_cycles]  = (v + 1 < nb_vals) ? vals[v + 1] : 0;
            p.nb_cycles++;
        }

        if (p.nb_cycles > 0)
            processes[n++] = p;
    }

    fclose(f);
    return n;
}

/**
 * @brief Point d'entrée principal.
 */
int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Usage : %s <fichier_processus.txt>\n", argv[0]);
        return 1;
    }

    Process processes[MAX_PROCESSES];
    int n = load_processes(argv[1], processes);

    if (n <= 0) {
        fprintf(stderr, "Aucun processus chargé.\n");
        return 1;
    }

    printf("Chargement de %d processus depuis '%s'.\n", n, argv[1]);

    fifo_schedule(processes, n);

    print_timeline(processes, n, "FIFO");
    print_metrics(processes, n, "FIFO");
    save_csv(processes, n, "FIFO", "resultats_fifo.csv");

    return 0;
}
