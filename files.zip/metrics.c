/**
 * @file metrics.c
 * @brief Implémentation du calcul et de l'affichage des indicateurs.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "metrics.h"

/* -----------------------------------------------------------------------
 * Fonctions internes
 * ----------------------------------------------------------------------- */

/**
 * @brief Retourne le total des cycles CPU d'un processus.
 */
static int total_cpu(Process *p)
{
    int sum = 0;
    for (int c = 0; c < p->nb_cycles; c++) sum += p->cpu_bursts[c];
    return sum;
}

/**
 * @brief Retourne le total des cycles E/S d'un processus.
 */
static int total_io(Process *p)
{
    int sum = 0;
    for (int c = 0; c < p->nb_cycles; c++) sum += p->io_bursts[c];
    return sum;
}

/**
 * @brief Retourne la fin de la dernière activité d'un processus
 *        (CPU ou E/S, selon ce qui se termine en dernier).
 */
static int last_event(Process *p)
{
    int last = p->finish_time;
    for (int c = 0; c < p->nb_cycles; c++)
        if (p->io_bursts[c] > 0 && p->io_finish[c] > last)
            last = p->io_finish[c];
    return last;
}

/**
 * @brief Calcule le taux d'occupation du CPU en pourcentage.
 */
static double cpu_utilization(Process processes[], int n)
{
    int total    = 0;
    int t_start  = processes[0].arrival_time;
    int t_end    = 0;

    for (int i = 0; i < n; i++) {
        total  += total_cpu(&processes[i]);
        if (processes[i].arrival_time < t_start)
            t_start = processes[i].arrival_time;
        if (processes[i].finish_time > t_end)
            t_end = processes[i].finish_time;
    }

    int duration = t_end - t_start;
    if (duration == 0) return 0.0;
    return (double)total / duration * 100.0;
}

/**
 * @brief Détermine l'état d'un processus à l'instant t.
 *
 * Utilise exec_log[] pour les intervalles CPU — compatible avec
 * tous les algorithmes y compris les préemptifs (SJRF, RR).
 *
 * @return "CPU " / "E/S " / "WAIT" / "----" (non arrivé) / "    " (terminé)
 */
static const char *state_at(Process *p, int t)
{
    if (t < p->arrival_time) return "----";

    /* Vérifier si le processus est sur le CPU à l'instant t */
    for (int e = 0; e < p->nb_exec; e++)
        if (t >= p->exec_log[e].start && t < p->exec_log[e].end)
            return "CPU ";

    /* Vérifier si le processus fait des E/S à l'instant t */
    for (int c = 0; c < p->nb_cycles; c++)
        if (p->io_bursts[c] > 0
            && t >= p->io_start[c]
            && t < p->io_finish[c])
            return "E/S ";

    if (t >= p->finish_time) return "    "; /* terminé */
    return "WAIT";                           /* en attente */
}

/* -----------------------------------------------------------------------
 * Implémentation publique
 * ----------------------------------------------------------------------- */

/**
 * @brief Affiche la chronologie avec t en ligne et les processus en colonne.
 *
 * Chaque ligne correspond à une unité de temps.
 * Les états possibles sont : CPU, E/S, WAIT, ----, ou vide (terminé).
 */
void print_timeline(Process processes[], int n, const char *algo_name)
{
    /* Durée totale : fin de la dernière activité tous processus confondus */
    int total_time = 0;
    for (int i = 0; i < n; i++) {
        int le = last_event(&processes[i]);
        if (le > total_time) total_time = le;
    }

    printf("\n=== Chronologie : %s ===\n\n", algo_name);

    /* En-tête */
    printf("%-6s", "t");
    for (int i = 0; i < n; i++)
        printf("  P%-4d", processes[i].pid);
    printf("\n");

    /* Séparateur */
    printf("------");
    for (int i = 0; i < n; i++) printf("-------");
    printf("\n");

    /* Une ligne par unité de temps */
    for (int t = 0; t < total_time; t++) {
        printf("%-6d", t);
        for (int i = 0; i < n; i++)
            printf("  %-4s  ", state_at(&processes[i], t));
        printf("\n");
    }
    printf("\n");
}

/**
 * @brief Affiche les résultats dans la console (format tabulaire).
 */
void print_metrics(Process processes[], int n, const char *algo_name)
{
    double sum_wait = 0, sum_turn = 0, sum_resp = 0;

    printf("\n=== Résultats algorithme : %s ===\n\n", algo_name);
    printf("%-5s %-10s %-7s %-10s %-10s %-12s %-14s %-12s\n",
           "PID", "Arrivée", "Cycles",
           "Total_CPU", "Total_E/S",
           "Attente", "Restitution", "Réponse");
    printf("--------------------------------------------------------------------------\n");

    for (int i = 0; i < n; i++) {
        Process *p = &processes[i];
        printf("%-5d %-10d %-7d %-10d %-10d %-12d %-14d %-12d\n",
               p->pid, p->arrival_time, p->nb_cycles,
               total_cpu(p), total_io(p),
               p->waiting_time, p->turnaround_time, p->response_time);
        sum_wait += p->waiting_time;
        sum_turn += p->turnaround_time;
        sum_resp += p->response_time;
    }

    printf("--------------------------------------------------------------------------\n");
    printf("Temps d'attente moyen    : %.2f ms\n", sum_wait / n);
    printf("Temps de restitution moy : %.2f ms\n", sum_turn / n);
    printf("Temps de réponse moyen   : %.2f ms\n", sum_resp / n);
    printf("Taux d'occupation CPU    : %.2f %%\n",  cpu_utilization(processes, n));
}

/**
 * @brief Sauvegarde les résultats dans un fichier CSV.
 */
void save_csv(Process processes[], int n, const char *algo_name,
              const char *filename)
{
    FILE *f = fopen(filename, "w");
    if (!f) { perror("Erreur ouverture CSV"); return; }

    fprintf(f, "Algorithme;PID;Arrivee_ms;Cycles;Total_CPU_ms;Total_ES_ms;"
               "Attente_ms;Restitution_ms;Reponse_ms\n");

    double sum_wait = 0, sum_turn = 0, sum_resp = 0;

    for (int i = 0; i < n; i++) {
        Process *p = &processes[i];
        fprintf(f, "%s;%d;%d;%d;%d;%d;%d;%d;%d\n",
                algo_name, p->pid, p->arrival_time, p->nb_cycles,
                total_cpu(p), total_io(p),
                p->waiting_time, p->turnaround_time, p->response_time);
        sum_wait += p->waiting_time;
        sum_turn += p->turnaround_time;
        sum_resp += p->response_time;
    }

    fprintf(f, "%s;MOYENNE;;;;;%.2f;%.2f;%.2f\n",
            algo_name, sum_wait / n, sum_turn / n, sum_resp / n);
    fprintf(f, "%s;CPU_UTILIZATION;;;;;;%.2f%%\n",
            algo_name, cpu_utilization(processes, n));

    fclose(f);
    printf("Résultats sauvegardés dans : %s\n", filename);
}
