/**
 * @file fifo.c
 * @brief Implémentation de l'algorithme FIFO avec gestion multi-cycles.
 *
 * Un processus peut avoir plusieurs cycles CPU et E/S alternés.
 * La simulation est pilotée par événements :
 *   - arrivée d'un processus → file d'attente
 *   - fin d'un cycle CPU     → démarrage E/S ou cycle suivant
 *   - fin d'un cycle E/S     → retour en file d'attente
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "fifo.h"

/* -----------------------------------------------------------------------
 * Fonctions internes
 * ----------------------------------------------------------------------- */

/**
 * @brief Insère un processus dans la file d'attente triée par
 *        (ready_time, arrival_time) pour respecter l'ordre FIFO.
 *
 * @param rq         Tableau des indices en file
 * @param rq_t       Tableau des temps d'entrée en file
 * @param rq_size    Taille courante de la file (modifié)
 * @param idx        Indice du processus à insérer
 * @param ready_t    Moment où le processus est devenu prêt
 * @param processes  Tableau global des processus (pour tiebreak)
 */
static void rq_insert(int rq[], int rq_t[], int *rq_size,
                      int idx, int ready_t, Process processes[])
{
    /*
     * Trouver la position d'insertion :
     *   - en priorité le plus petit ready_t
     *   - en cas d'égalité, le plus petit arrival_time (FIFO strict)
     */
    int pos = *rq_size;
    for (int j = 0; j < *rq_size; j++) {
        if (ready_t < rq_t[j] ||
            (ready_t == rq_t[j] &&
             processes[idx].arrival_time < processes[rq[j]].arrival_time))
        {
            pos = j;
            break;
        }
    }

    /* Décaler les éléments vers la droite */
    for (int j = *rq_size; j > pos; j--) {
        rq[j]   = rq[j - 1];
        rq_t[j] = rq_t[j - 1];
    }
    rq[pos]   = idx;
    rq_t[pos] = ready_t;
    (*rq_size)++;
}

/* -----------------------------------------------------------------------
 * Implémentation publique
 * ----------------------------------------------------------------------- */

/**
 * @brief Exécute l'algorithme FIFO multi-cycles sur un tableau de processus.
 *
 * Algorithme :
 *   1. Ajouter dans la file tous les processus devenus prêts
 *      (arrivés ou ayant terminé leur E/S) avant current_time.
 *   2. Si la file est vide → avancer l'horloge au prochain événement.
 *   3. Dépiler le premier processus (FIFO) et exécuter son cycle CPU.
 *   4. Démarrer l'E/S du cycle si nécessaire.
 *   5. Répéter jusqu'à ce que tous les processus soient terminés.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 */
void fifo_schedule(Process processes[], int n)
{
    int proc_cycle[MAX_PROCESSES]; /**< Cycle courant de chaque processus */
    int io_end[MAX_PROCESSES];     /**< Fin de l'E/S en cours, -1 si aucune */
    int in_ready[MAX_PROCESSES];   /**< 1 si déjà dans la file */
    int finished[MAX_PROCESSES];   /**< 1 si le processus est terminé */

    memset(proc_cycle, 0, sizeof(int) * n);
    memset(in_ready,   0, sizeof(int) * n);
    memset(finished,   0, sizeof(int) * n);
    for (int i = 0; i < n; i++) io_end[i] = -1;

    /* File d'attente : indices et temps d'entrée */
    int rq[MAX_PROCESSES * MAX_CYCLES];
    int rq_t[MAX_PROCESSES * MAX_CYCLES];
    int rq_size = 0;

    /* Horloge : commence à la première arrivée */
    int current_time = processes[0].arrival_time;
    for (int i = 1; i < n; i++)
        if (processes[i].arrival_time < current_time)
            current_time = processes[i].arrival_time;

    int done_count = 0;

    while (done_count < n) {

        /* ── Étape 1 : ajouter les processus devenus prêts ──────────────── */
        for (int i = 0; i < n; i++) {
            if (in_ready[i] || finished[i]) continue;

            if (proc_cycle[i] == 0
                && processes[i].arrival_time <= current_time)
            {
                rq_insert(rq, rq_t, &rq_size, i,
                          processes[i].arrival_time, processes);
                in_ready[i] = 1;
            }
            else if (proc_cycle[i] > 0
                     && io_end[i] >= 0
                     && io_end[i] <= current_time)
            {
                rq_insert(rq, rq_t, &rq_size, i, io_end[i], processes);
                in_ready[i] = 1;
                io_end[i]   = -1;
            }
        }

        /* ── Étape 2 : si file vide → avancer l'horloge ─────────────────── */
        if (rq_size == 0) {
            int next = INT_MAX;
            for (int i = 0; i < n; i++) {
                if (finished[i]) continue;
                if (proc_cycle[i] == 0
                    && processes[i].arrival_time > current_time
                    && processes[i].arrival_time < next)
                    next = processes[i].arrival_time;
                if (io_end[i] > current_time && io_end[i] < next)
                    next = io_end[i];
            }
            if (next == INT_MAX) break; /* ne devrait pas arriver */
            current_time = next;
            continue;
        }

        /* ── Étape 3 : dépiler le premier processus (FIFO) ──────────────── */
        int idx = rq[0];
        for (int j = 0; j < rq_size - 1; j++) {
            rq[j]   = rq[j + 1];
            rq_t[j] = rq_t[j + 1];
        }
        rq_size--;
        in_ready[idx] = 0;

        Process *p = &processes[idx];
        int c = proc_cycle[idx];

        /* ── Étape 4 : exécuter le cycle CPU ─────────────────────────────── */
        p->cpu_start[c] = current_time;
        if (c == 0) p->start_time = current_time;

        current_time += p->cpu_bursts[c];
        p->cpu_finish[c] = current_time;

        /* Enregistrer l'intervalle dans exec_log (utile pour algos préemptifs) */
        if (p->nb_exec < MAX_EXEC_INTERVALS) {
            p->exec_log[p->nb_exec].start = p->cpu_start[c];
            p->exec_log[p->nb_exec].end   = p->cpu_finish[c];
            p->exec_log[p->nb_exec].cycle = c;
            p->nb_exec++;
        }

        /* ── Étape 5 : démarrer l'E/S si nécessaire ─────────────────────── */
        if (p->io_bursts[c] > 0) {
            p->io_start[c]  = current_time;
            p->io_finish[c] = current_time + p->io_bursts[c];
            io_end[idx]     = p->io_finish[c];
        }

        proc_cycle[idx]++;

        /* ── Étape 6 : vérifier si le processus est terminé ─────────────── */
        if (proc_cycle[idx] >= p->nb_cycles) {
            p->finish_time = current_time;
            finished[idx]  = 1;
            done_count++;
        } else if (p->io_bursts[c] == 0) {
            /*
             * Pas d'E/S pour ce cycle → le processus repart directement
             * en fin de file d'attente (ready_t = current_time).
             */
            rq_insert(rq, rq_t, &rq_size, idx, current_time, processes);
            in_ready[idx] = 1;
        }
    }

    /* ── Calcul des indicateurs de performance ────────────────────────── */
    for (int i = 0; i < n; i++) {
        Process *p = &processes[i];
        p->response_time   = p->start_time  - p->arrival_time;
        p->turnaround_time = p->finish_time  - p->arrival_time;

        int total_cpu = 0, total_io = 0;
        for (int c = 0; c < p->nb_cycles; c++) {
            total_cpu += p->cpu_bursts[c];
            total_io  += p->io_bursts[c];
        }
        /* Attente = temps de restitution - temps utile (CPU + E/S parallélisées) */
        p->waiting_time = p->turnaround_time - total_cpu - total_io;
    }
}
