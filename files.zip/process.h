/**
 * @file process.h
 * @brief Définition de la structure représentant un processus.
 *
 * Un processus possède plusieurs cycles CPU et E/S alternés :
 *   cpu_bursts[0] → io_bursts[0] → cpu_bursts[1] → io_bursts[1] → ...
 *
 * Le dernier cycle CPU n'a généralement pas d'E/S (io_bursts[nb_cycles-1] = 0).
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef PROCESS_H
#define PROCESS_H

/** Nombre maximum de processus supportés */
#define MAX_PROCESSES 64

/** Nombre maximum de cycles CPU par processus */
#define MAX_CYCLES 16

/**
 * Nombre maximum d'intervalles d'exécution CPU par processus.
 * Un cycle CPU préemptif peut être découpé en plusieurs morceaux.
 * Ex : RR avec quantum=2 sur un cpu_burst=6 → 3 intervalles.
 * On prévoit 10 intervalles par cycle pour couvrir les cas extrêmes.
 */
#define MAX_EXEC_INTERVALS (MAX_CYCLES * 10)

/**
 * @brief Intervalle d'exécution CPU enregistré par l'ordonnanceur.
 *
 * Chaque fois qu'un processus obtient le CPU — même brièvement —
 * l'ordonnanceur enregistre un ExecInterval dans exec_log[].
 * Pour les algos non-préemptifs (FIFO, SJF), nb_exec == nb_cycles.
 * Pour les algos préemptifs (SJRF, RR), nb_exec peut être > nb_cycles.
 */
typedef struct {
    int start; /**< Début de l'intervalle (ms) */
    int end;   /**< Fin de l'intervalle (ms)   */
    int cycle; /**< Numéro du cycle CPU auquel appartient cet intervalle */
} ExecInterval;

/**
 * @brief Structure représentant un processus à ordonnancer.
 *
 * Les champs cpu_start, cpu_finish, io_start, io_finish sont des tableaux
 * indexés par le numéro de cycle. Ils sont remplis par l'ordonnanceur.
 *
 * Les indicateurs (waiting_time, turnaround_time, response_time) sont
 * calculés en fin de simulation à partir des timings de chaque cycle.
 */
typedef struct {
    int pid;                         /**< Identifiant unique */
    int arrival_time;                /**< Date d'arrivée (ms) */

    /* Cycles définis par l'utilisateur */
    int cpu_bursts[MAX_CYCLES];      /**< Durée de chaque cycle CPU (ms) */
    int io_bursts[MAX_CYCLES];       /**< Durée de chaque cycle E/S après le CPU (ms) */
    int nb_cycles;                   /**< Nombre de cycles CPU */

    /* Timings calculés par l'ordonnanceur — un par cycle */
    int cpu_start[MAX_CYCLES];       /**< Début de chaque cycle CPU */
    int cpu_finish[MAX_CYCLES];      /**< Fin de chaque cycle CPU */
    int io_start[MAX_CYCLES];        /**< Début de chaque cycle E/S */
    int io_finish[MAX_CYCLES];       /**< Fin de chaque cycle E/S */

    /* Log de toutes les exécutions CPU (utile pour algos préemptifs) */
    ExecInterval exec_log[MAX_EXEC_INTERVALS]; /**< Intervalles d'exécution CPU */
    int          nb_exec;                       /**< Nombre d'intervalles enregistrés */

    /* Indicateurs globaux */
    int start_time;                  /**< Première exécution CPU (= cpu_start[0]) */
    int finish_time;                 /**< Fin du dernier cycle CPU */
    int waiting_time;                /**< Temps passé en attente (ni CPU ni E/S) */
    int turnaround_time;             /**< finish_time - arrival_time */
    int response_time;               /**< start_time  - arrival_time */
} Process;

#endif /* PROCESS_H */
