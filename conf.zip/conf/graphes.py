#!/usr/bin/env python3
"""
Script de génération de graphiques à partir de fichiers CSV.

Auteur : Valentin

Usage :
    python3 graphes.py fichier1.csv [fichier2.csv ...]

Fonctionnalités :
- Génère un PNG de graphiques : <nom>_graphs.png
- Génère un fichier Excel avec données + graphique : <nom>.xlsx
- Si plusieurs CSV sont fournis : crée aussi une comparaison des algorithmes
  (comparaison_algos.png et comparaison_algos.xlsx)
"""

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Font, PatternFill, Alignment

# Dossier de sortie pour les fichiers générés
OUTPUT_DIR = "resultats_graphes"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def load(path):
    """Charge un CSV et nettoie les colonnes numériques."""
    if not os.path.isfile(path):
        print(f"Erreur : fichier introuvable '{path}'")
        sys.exit(1)
    df = pd.read_csv(path, sep=";", dtype=str)
    df = df[~df["PID"].isin(["MOYENNE", "CPU_UTILIZATION"])].copy()
    for col in ["Attente_ms", "Restitution_ms", "Reponse_ms"]:
        df[col] = pd.to_numeric(df[col].str.replace(",", "."), errors="coerce").fillna(0)
    algo = df["Algorithme"].iloc[0] if "Algorithme" in df.columns else os.path.basename(path)
    return df, algo


def plot_one(path):
    """Crée les graphiques pour un fichier CSV et sauvegarde le PNG."""
    df, algo = load(path)
    fig, axes = plt.subplots(1, 3, figsize=(14, 5))
    fig.suptitle(f"Algorithme : {algo}", fontsize=13, fontweight="bold")

    # Barplots pour les trois métriques
    df.plot.bar(x="PID", y="Attente_ms",     ax=axes[0], title="Temps d'attente",     legend=False, color="#4C72B0")
    df.plot.bar(x="PID", y="Restitution_ms", ax=axes[1], title="Temps de restitution", legend=False, color="#DD8452")
    df.plot.bar(x="PID", y="Reponse_ms",     ax=axes[2], title="Temps de réponse",    legend=False, color="#55A868")

    # Mise en forme des axes
    for ax in axes:
        ax.set_xlabel("PID")
        ax.set_ylabel("ms")
        ax.tick_params(axis="x", rotation=0)
        ax.grid(axis="y", linestyle="--", alpha=0.5)

    plt.tight_layout()
    name = os.path.splitext(os.path.basename(path))[0]
    png_path = os.path.join(OUTPUT_DIR, f"{name}_.png")
    plt.savefig(png_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Sauvegardé : {png_path}")
    return png_path, df, algo


def export_xlsx(df, algo, png_path, xlsx_path):
    """Exporte les données et le graphique dans un fichier Excel."""
    wb = Workbook()
    ws = wb.active
    ws.title = algo

    # --- En-tête ---
    headers = ["PID", "Attente (ms)", "Restitution (ms)", "Réponse (ms)"]
    header_fill = PatternFill("solid", start_color="4C72B0")
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    # --- Données ---
    for _, row in df.iterrows():
        ws.append([row["PID"], row["Attente_ms"], row["Restitution_ms"], row["Reponse_ms"]])

    # --- Ligne moyenne ---
    last = ws.max_row
    ws.append([
        "Moyenne",
        f"=AVERAGE(B2:B{last})",
        f"=AVERAGE(C2:C{last})",
        f"=AVERAGE(D2:D{last})",
    ])
    avg_fill = PatternFill("solid", start_color="E8F0FE")
    for col in range(1, 5):
        cell = ws.cell(row=last + 1, column=col)
        cell.font = Font(bold=True)
        cell.fill = avg_fill

    # Largeur colonnes
    for col, width in zip("ABCD", [8, 16, 18, 16]):
        ws.column_dimensions[col].width = width

    # --- Image PNG ---
    img = XLImage(png_path)
    img.anchor = "F1"
    ws.add_image(img)

    wb.save(xlsx_path)
    print(f"Sauvegardé : {xlsx_path}")


def plot_comparison(paths):
    """Crée des graphiques comparatifs si plusieurs CSV sont fournis."""
    records = []
    for path in paths:
        df, algo = load(path)
        records.append({
            "Algo":             algo,
            "Attente moy.":     df["Attente_ms"].mean(),
            "Restitution moy.": df["Restitution_ms"].mean(),
            "Réponse moy.":     df["Reponse_ms"].mean(),
        })

    summary = pd.DataFrame(records).set_index("Algo")
    ax = summary.plot.bar(figsize=(10, 5), edgecolor="white")
    ax.set_title("Comparaison des algorithmes — moyennes", fontsize=13, fontweight="bold")
    ax.set_ylabel("Temps moyen (ms)")
    ax.tick_params(axis="x", rotation=0)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    plt.tight_layout()
    png = os.path.join(OUTPUT_DIR, "comparaison_algos.png")
    plt.savefig(png, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Sauvegardé : {png}")

    # Export xlsx comparaison
    wb = Workbook()
    ws = wb.active
    ws.title = "Comparaison"
    ws.append(["Algo", "Attente moy. (ms)", "Restitution moy. (ms)", "Réponse moy. (ms)"])
    header_fill = PatternFill("solid", start_color="4C72B0")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
    for r in records:
        ws.append([r["Algo"], r["Attente moy."], r["Restitution moy."], r["Réponse moy."]])
    for col, width in zip("ABCD", [10, 20, 24, 20]):
        ws.column_dimensions[col].width = width
    img = XLImage(png)
    img.anchor = "F1"
    ws.add_image(img)
    xlsx = os.path.join(OUTPUT_DIR, "comparaison_algos.xlsx")
    wb.save(xlsx)
    print(f"Sauvegardé : {xlsx}")


if __name__ == "__main__":
    # Vérifie la présence d'au moins un fichier CSV
    if len(sys.argv) < 2:
        print("Usage : python3 graphes.py fichier.csv [fichier2.csv ...]")
        sys.exit(1)

    # Génération des graphes et Excel pour chaque fichier CSV
    for path in sys.argv[1:]:
        png_path, df, algo = plot_one(path)
        name = os.path.splitext(os.path.basename(path))[0]
        xlsx_path = os.path.join(OUTPUT_DIR, f"{name}.xlsx")
        export_xlsx(df, algo, png_path, xlsx_path)

    # Génération de la comparaison si plusieurs fichiers CSV
    if len(sys.argv) > 2:
        plot_comparison(sys.argv[1:])