/**
 * @file config.c
 * @brief Lecture de conf.ini pour initialiser les paramètres de simulation.
 *
 * @authors Valentin (33%), Longzhou (33%), Mathéo (33%)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "config.h"


// Valeurs par défaut appliquées si conf.ini est absent ou incomplet
static void set_defaults(Config *cfg)
{
    strncpy(cfg->algo, "FIFO", CONFIG_ALGO_LEN - 1);
    strncpy(cfg->datafile, "data/test_processus.txt", CONFIG_PATH_LEN - 1);
    strncpy(cfg->csv_prefix, "resultats_", CONFIG_PREFIX_LEN - 1);

    cfg->algo[CONFIG_ALGO_LEN - 1] = '\0';
    cfg->datafile[CONFIG_PATH_LEN - 1] = '\0';
    cfg->csv_prefix[CONFIG_PREFIX_LEN-1] = '\0';

    cfg->quantum  = 4;
    cfg->save_csv = 1;
}

// Supprime les espaces en début et en fin de chaine (in-place)
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    if (*s == '\0') return s;

    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end))
        *end-- = '\0';

    return s;
}

static void to_upper(char *s, int n)
{
    int i;
    for (i = 0; i < n && s[i]; i++) {
        s[i] = (char)toupper((unsigned char)s[i]);
	}
}

static void apply_pair(Config *cfg, const char *key, const char *val)
{
    if (strcmp(key, "algo") == 0) {
        strncpy(cfg->algo, val, CONFIG_ALGO_LEN - 1);
        cfg->algo[CONFIG_ALGO_LEN - 1] = '\0';
        to_upper(cfg->algo, CONFIG_ALGO_LEN);

    } else if (strcmp(key, "quantum") == 0) {
        int q = atoi(val);
        if (q > 0)
            cfg->quantum = q;
        else {
            fprintf(stderr, "conf.ini : quantum invalide ('%s') - ignoré.\n", val);
		}
    } else if (strcmp(key, "datafile") == 0) {
        strncpy(cfg->datafile, val, CONFIG_PATH_LEN - 1);
        cfg->datafile[CONFIG_PATH_LEN - 1] = '\0';

    } else if (strcmp(key, "save_csv") == 0) {
        cfg->save_csv = (strcmp(val, "true") == 0);

    } else if (strcmp(key, "csv_prefix") == 0) {
        strncpy(cfg->csv_prefix, val, CONFIG_PREFIX_LEN - 1);
        cfg->csv_prefix[CONFIG_PREFIX_LEN - 1] = '\0';
    }
}


void config_load(const char *filename, Config *cfg)
{
    set_defaults(cfg);

    FILE *f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Info : '%s' introuvable, valeurs par défaut utilisées.\n", filename);
        return;
    }

    char line[256];
    int  ln = 0;

    while (fgets(line, sizeof(line), f)) {
        ln++;
        char *s = trim(line);

        // ignorer commentaires, sections INI et lignes vides
        if (*s == '#' || *s == ';' || *s == '[' || *s == '\0')
            continue;

        char *eq = strchr(s, '=');
        if (!eq) {
            fprintf(stderr, "conf.ini:%d : pas de '=' - ligne ignorée.\n", ln);
            continue;
        }

        *eq = '\0';
        char *key = trim(s);
        char *val = trim(eq + 1);

        // enlever un éventuel commentaire en fin de valeur
        char *cmt = strpbrk(val, "#;");
        if (cmt) { *cmt = '\0'; val = trim(val); }

        if (*key) apply_pair(cfg, key, val);
    }

    fclose(f);
}

void config_print(const Config *cfg)
{
    printf("-- Configuration -----------------------------------\n");
    printf("  Fichier données : %s\n", cfg->datafile);
    printf("  Algorithme      : %s\n", cfg->algo);
    if (strcmp(cfg->algo, "RR") == 0)
        printf("  Quantum         : %d ms\n", cfg->quantum);
    printf("  Sauvegarde CSV  : %s\n", cfg->save_csv ? "oui" : "non");
    printf("  Préfixe CSV     : %s\n", cfg->csv_prefix);
    printf("----------------------------------------------------\n");
}
