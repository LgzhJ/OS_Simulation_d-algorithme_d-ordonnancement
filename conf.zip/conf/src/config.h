/**
 * @file config.h
 * @brief Lecture et gestion de la configuration depuis conf.ini.
 *
 * Les arguments CLI ont toujours la priorité sur conf.ini.
 * Si le fichier est absent, des valeurs par défaut sont appliquées.
 *
 * @authors Valentin (75%), Longzhou (25%)
 */

#ifndef CONFIG_H
#define CONFIG_H

#define CONFIG_ALGO_LEN   8
#define CONFIG_PATH_LEN   256
#define CONFIG_PREFIX_LEN 64

/* Paramètres de simulation chargés depuis conf.ini */
typedef struct {
    char algo[CONFIG_ALGO_LEN]; // "FIFO", "SJF", "RR" ou "SRJF"
    int quantum; // quantum RR en ms
    char datafile[CONFIG_PATH_LEN]; // chemin du fichier de données
    int save_csv; // 1 = sauvegarder en CSV
    char csv_prefix[CONFIG_PREFIX_LEN]; // préfixe des fichiers CSV
} Config;

/**
 * @brief Charge la configuration depuis un fichier INI.
 * Si le fichier est absent, les valeurs par défaut sont conservées.
 *
 * @param filename Chemin vers conf.ini
 * @param config   Structure à remplir
 */
void config_load(const char *filename, Config *config);

/**
 * @brief Affiche la configuration active.
 */
void config_print(const Config *config);

#endif
