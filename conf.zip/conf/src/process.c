/**
 * @file process.c
 * @brief Fonctions de gestion d'un processus multi-burst.
 *
 * Toute la logique d'état est ici. Les algorithmes d'ordonnancement
 * utilisent uniquement ces fonctions directement les champs de la structure.
 *
 * @authors Mathéo (33%), Valentin (33%), Longzhou (33%)
 */

#include <limits.h>
#include "process.h"

/* Déclaration anticipée : process_finish est appelée dans process_end_burst. */
static void process_finish(Process *p, int finish_time);


void process_reset(Process *p)
{
    p->current_burst = 0;
    p->blocked_io = 0;
    p->io_end_time = 0;
    p->has_started = 0;
    p->is_done = 0;
    p->start_time = 0;
    p->finish_time = 0;
    p->waiting_time = 0;
    p->turnaround_time = 0;
    p->response_time = 0;

    // cpu_left = durée du premier burst CPU (0 si aucun burst)
    if (p->nb_bursts > 0) {
        p->cpu_left = p->bursts[0];
	} else {
        p->cpu_left = 0;
	}
}

int process_is_ready(const Process *p, int current_time)
{
    if (p->is_done) return 0;
    if (p->arrival_time > current_time) return 0;
    if (p->blocked_io && p->io_end_time > current_time) return 0;
    return 1;
}

int process_is_done(const Process *p)
{
    return p->is_done;
}

void process_on_start(Process *p, int current_time)
{
    // On n'enregistre que le tout premier passage sur le CPU
    if (!p->has_started) {
        p->start_time = current_time;
        p->response_time = current_time - p->arrival_time;
        p->has_started = 1;
    }
}

int process_run(Process *p, int duration)
{
    int time_used = (duration < p->cpu_left) ? duration : p->cpu_left;
    p->cpu_left -= time_used;
    return time_used;
}

void process_end_burst(Process *p, int current_time)
{
    int last_burst = p->nb_bursts - 1;

    /* Dernier burst CPU -> processus terminé */
    if (p->current_burst >= last_burst) {
        process_finish(p, current_time);
        return;
    }

    int io_index = p->current_burst * 2 + 1;
    int io_duration = p->bursts[io_index];

    p->current_burst++;

    if (io_duration > 0) {
        /* E/S bloquante, on attend sa fin */
        p->blocked_io = 1;
        p->io_end_time = current_time + io_duration;
    } else {
		
        /* Pas d'e/s entre deux CPU : prêt immédiatement */
        int next_cpu = p->current_burst * 2;
        p->cpu_left = p->bursts[next_cpu];
    }
}

int process_next_event(const Process *p)
{
    if (p->blocked_io) return p->io_end_time;
    return -1;
}

void process_resume(Process *p, int current_time)
{
    if (p->blocked_io && p->io_end_time <= current_time) {
        p->blocked_io = 0;
		
        int next_cpu = p->current_burst * 2;
        p->cpu_left = p->bursts[next_cpu];
    }
}

int process_next_global_event(Process processes[], int n, int current_time)
{
    int earliest = INT_MAX;
    int i;

    for (i = 0; i < n; i++) {
        if (processes[i].is_done) continue;

        if (processes[i].arrival_time > current_time && processes[i].arrival_time < earliest) {
			earliest = processes[i].arrival_time; 
		}

        int io_evt = process_next_event(&processes[i]);
        if (io_evt > current_time && io_evt < earliest) {
			earliest = io_evt;
		}
    }

    return earliest;
}


static void process_finish(Process *p, int finish_time)
{
    int total_intermediate_io = 0, i;

    p->finish_time     = finish_time;
    p->turnaround_time = finish_time - p->arrival_time;

    /* On ne compte que les E/S intercalées entre deux bursts CPU.
     * L'éventuelle E/S après le dernier CPU est ignorée (elle se déroule en parallèle et ne bloque plus le processus). */
    for (i = 0; i < p->nb_bursts - 1; i++){
        total_intermediate_io += p->bursts[i * 2 + 1];
	}	

    p->waiting_time = p->turnaround_time - p->total_cpu - total_intermediate_io;
    p->is_done      = 1;
}
