/**
 * @file process.h
 * @brief Définition de la structure Process et de ses fonctions de gestion.
 *
 * Un processus peut avoir plusieurs cycles CPU séparés par des cycles E/S.
 * Le tableau `bursts` stocke les durées en alternance :
 *   bursts[0] = durée CPU 0
 *   bursts[1] = durée E/S 0
 *   bursts[2] = durée CPU 1
 *   bursts[3] = durée E/S 1
 *   ...
 *
 * Seules les E/S entre deux CPU bloquent le processus.
 * L'E/S après le dernier CPU est ignorée (elle se fait en parallèle).
 *
 * Métriques calculées :
 *   finish_time = moment où le dernier cycle CPU se termine
 *   turnaround_time = finish_time - arrival_time
 *   waiting_time = turnaround_time - total_cpu - somme(E/S intercalées)
 *   response_time = start_time - arrival_time
 *
 * @authors Mathéo (33%), Valentin (33%), Longzhou (33%)
 */

#ifndef PROCESS_H
#define PROCESS_H

/* Nombre maximum de processus dans la simulation */
#define MAX_PROCESSES 64

/* Nombre maximum de cycles CPU par processus.
 * Le tableau bursts a 2 * MAX_BURSTS cases (cpu + io en alternance). */
#define MAX_BURSTS 8

typedef struct {
    int pid; /* Identifiant du processus */
    int arrival_time; /* Date d'arrivée (ms) */
    int nb_bursts; /* Nombre de cycles CPU  */
    int bursts[MAX_BURSTS * 2]; /* Durées alternées : cpu0, io0, cpu1 */
    int total_cpu; /* Somme de tous les cycles CPU (ms) */
    int total_io; /* Somme de tous les cycles E/S (ms) */
	

    int current_burst; /* Index du cycle CPU en cours (0, 1, 2 ...) */
    int cpu_left; /* Temps CPU restant dans le burst courant */
    int blocked_io; /* 1 si le processus attend la fin d'une E/S */
    int io_end_time; /* Moment où l'E/S en cours se termine */
    int has_started; /* 1 si le processus a déjà reçu le CPU */
    int is_done; /* 1 si le processus est complètement terminé */
	

    int start_time;
    int finish_time;
    int waiting_time;
    int turnaround_time;
    int response_time;

} Process;

/**
 * @brief Remet le processus à zéro avant une simulation.
 *
 * Réinitialise tous les champs d'état et de métriques.
 * Les données d'entrée (pid, bursts, etc.) ne sont pas effacées.
 */
void process_reset(Process *p);

/**
 * @brief Renvoie 1 si le processus est prêt à recevoir le CPU, 0 sinon.
 *
 * Un processus est prêt s'il est arrivé, non terminé, et non bloqué en E/S.
 */
int process_is_ready(const Process *p, int current_time);

/**
 * @brief Renvoie 1 si le processus a terminé tous ses cycles CPU.
 */
int process_is_done(const Process *p);

/**
 * @brief Enregistre le premier démarrage sur le CPU.
 *
 * Positionne start_time et response_time. Sans effet si déjà appelée.
 */
void process_on_start(Process *p, int current_time);

/**
 * @brief Fait avancer le processus de `duration` ms au maximum.
 *
 * Ne dépasse pas cpu_left. Retourne le temps réellement consommé.
 */
int process_run(Process *p, int duration);

/**
 * @brief Appelée quand cpu_left == 0 (fin d'un cycle CPU).
 *
 * Gère les transitions :
 *  - Dernier burst CPU -> marque le processus terminé.
 *  - Burst suivi d'une E/S -> met blocked_io = 1 et calcule io_end_time.
 *  - Burst sans E/S mais d'autres suivent -> charge le prochain burst.
 */
void process_end_burst(Process *p, int current_time);

/**
 * @brief Renvoie la date de fin de l'E/S en cours, ou -1 si pas en E/S.
 */
int process_next_event(const Process *p);

/**
 * @brief Débloque le processus si son E/S est terminée.
 *
 * Si blocked_io == 1 et io_end_time <= current_time :
 *   - blocked_io = 0
 *   - cpu_left = durée du prochain cycle CPU
 */
void process_resume(Process *p, int current_time);

/**
 * @brief Renvoie la date du prochain événement global (arrivée ou fin d'E/S).
 *
 * Parcourt tous les processus non terminés et retourne le premier instant
 * strictement supérieur à current_time où un processus devient prêt :
 *   - Arrivée d'un processus pas encore démarré.
 *   - Fin d'une E/S bloquante.
 *
 * @return La date du prochain événement, ou INT_MAX si aucun événement prévu.
 *
 * Utilisée par les algorithmes pour avancer l'horloge quand aucun
 * processus n'est prêt (CPU idle).
 */
int process_next_global_event(Process processes[], int n, int current_time);

#endif
