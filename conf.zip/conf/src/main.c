/**
 * @file main.c
 * @brief Point d'entrée du simulateur d'ordonnancement multi-burst.
 *
 * Usage : ./scheduler [<fichier.txt>] [<ALGO>] [quantum]
 *
 * Les valeurs par défaut sont lues dans conf.ini.
 * Les arguments CLI ont toujours la priorité.
 *
 * Algorithmes disponibles : FIFO, SJF, RR, SRJF
 *
 * Format du fichier d'entrée (une ligne par processus) :
 *   PID  arrival_time  cpu0 [io0  cpu1 [io1  cpu2 ...]]
 *
 * @authors Valentin (33%), Longzhou (33%), Matheo (33%)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "process.h"
#include "metrics.h"
#include "config.h"
#include "algos/fifo.h"
#include "algos/sjf.h"
#include "algos/rr.h"
#include "algos/srjf.h"

#define LINE_BUF 512

/* 
 * Retourne 1 si la ligne est un commentaire ou vide, 0 sinon
 */
static int is_blank_or_comment(const char *line)
{
    while (*line == ' ' || *line == '\t') line++;
    return (*line == '#' || *line == '\n' || *line == '\0');
}

/*
 * Lit et valide l'arrival_time (2e champ de la ligne).
 * Si manquant ou négatif, on utilise 0 avec un avertissement.
 */
static int parse_header(int line_num, Process *p)
{
    char *tok = strtok(NULL, " \t\n\r");
    if (!tok) {
        fprintf(stderr, "Avertissement ligne %d (PID %d) : arrival_time manquant - remplacé par 0.\n", line_num, p->pid);
        p->arrival_time = 0;
        return 1;
    }

    p->arrival_time = atoi(tok);
    if (p->arrival_time < 0) {
        fprintf(stderr, "Avertissement ligne %d (PID %d) : arrival_time négatif (%d) - remplacé par 0.\n", line_num, p->pid, p->arrival_time);
        p->arrival_time = 0;
    }
    return 1;
}

/**  
 * Parse les valeurs de bursts (alternance cpu/io).
 * Mode indulgent : valeur négative -> valeur absolue, burst CPU nul -> 1,
 * trop de bursts -> tronqué. Retourne 0 si aucun burst CPU. 
 */
static int parse_bursts(int line_num, Process *p, int *nb_values)
{
    int   b = 0;
    char *tok;

    while ((tok = strtok(NULL, " \t\n\r")) != NULL) {

        if (tok[0] == '#') break;

        if (b >= MAX_BURSTS * 2) {
            fprintf(stderr,
                "Avertissement ligne %d (PID %d) : trop de cycles - tronqué à %d bursts CPU.\n", line_num, p->pid, MAX_BURSTS);
            break;
        }

        int val = atoi(tok);

        if (val < 0) {
            fprintf(stderr,
                "Avertissement ligne %d (PID %d) : valeur négative (%d) position %d - remplacée par %d.\n",
                line_num, p->pid, val, b, -val);
            val = -val;
        }

        if (b % 2 == 0 && val == 0) {
            fprintf(stderr,
                "Avertissement ligne %d (PID %d) : burst CPU nul au burst %d - remplacé par 1.\n", line_num, p->pid, b/2 + 1);
            val = 1;
        }

        p->bursts[b++] = val;
    }

    if (b == 0) {
        fprintf(stderr,
            "Erreur ligne %d (PID %d) : aucun cycle CPU. Ligne ignorée.\n",
            line_num, p->pid);
        return 0;
    }

    *nb_values = b;
    return 1;
}

/**
 * Finalise le processus après parsing : calcule nb_bursts, total_cpu, total_io.
 * b impair -> dernier élément est un CPU sans E/S -> padding io = 0.
 */
static void finalize_process(Process *p, int b)
{
    int i;

    if (b % 2 == 1) {
        p->bursts[b] = 0;
        p->nb_bursts = (b + 1) / 2;
    } else {
        p->nb_bursts = b / 2;
    }

    for (i = 0; i < p->nb_bursts; i++) {
        p->total_cpu += p->bursts[i * 2];
        p->total_io  += p->bursts[i * 2 + 1];
    }

    process_reset(p);
}

/**
 * Tente de parser une ligne en un processus valide.
 * Retourne 1 si succès, 0 sinon.
 */
static int parse_line(char *line, int line_num, Process *p)
{
    *p = (Process){0};

    char *pid_tok = strtok(line, " \t\n\r");
    if (!pid_tok) return 0;
    p->pid = atoi(pid_tok);

    if (!parse_header(line_num, p))    return 0;

    int nb_values = 0;
    if (!parse_bursts(line_num, p, &nb_values)) return 0;

    finalize_process(p, nb_values);
    return 1;
}

/** 
 * Charge les processus depuis un fichier texte.
 * Retourne le nombre de processus chargés, -1 en cas d'erreur fatale. 
 */
static int load_processes(const char *filename, Process processes[])
{
    FILE *f = fopen(filename, "r");
    if (!f) { perror("Erreur ouverture fichier"); return -1; }

    int n = 0, ln = 0;
    char line[LINE_BUF];

    while (fgets(line, sizeof(line), f) && n < MAX_PROCESSES) {
        ln++;
        if (is_blank_or_comment(line)) { continue; }

        Process p;
        if (parse_line(line, ln, &p))
            processes[n++] = p;
    }

    fclose(f);
    return n;
}

/**
 * Construit le chemin CSV : <prefix><algo_minuscules>.csv 
 */
static void build_csv_name(const char *prefix, const char *algo, char *out, int out_len)
{
    char lower[CONFIG_ALGO_LEN];
    int i;
    for (i = 0; algo[i] && i < CONFIG_ALGO_LEN - 1; i++) {
        lower[i] = (char)tolower((unsigned char)algo[i]);
	}
    lower[i] = '\0';

    snprintf(out, out_len, "%s%s.csv", prefix, lower);
}

static void print_usage(const char *prog)
{
    fprintf(stderr,
        "Usage : %s [<fichier.txt>] [<ALGO>] [quantum]\n"
        "\n"
        "  Les valeurs par défaut sont lues dans conf.ini.\n"
        "  Les arguments CLI ont priorité sur conf.ini.\n"
        "\n"
        "  ALGO disponibles :\n"
        "    FIFO   - First In, First Out          (non-préemptif)\n"
        "    SJF    - Shortest Job First            (non-préemptif)\n"
        "    RR     - Round Robin                   (préemptif)\n"
        "    SRJF   - Shortest Remaining Job First  (préemptif)\n"
        "\n"
        "  Format fichier :\n"
        "    PID  arrival  cpu0 [io0  cpu1 [io1 ...]]\n"
        "\n"
        "  Exemples :\n"
        "    %s\n"
        "    %s data/test_rr.txt   RR   4\n"
        "    %s data/test_sjf.txt  SJF\n",
        prog, prog, prog, prog);
}


int main(int argc, char *argv[])
{
    if (argc >= 2
        && (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0)) {
        print_usage(argv[0]);
        return 0;
    }

    Config config;
    config_load("conf.ini", &config);

    const char *datafile = config.datafile;
    const char *algo     = config.algo;
    int quantum          = config.quantum;

    if (argc >= 2) datafile = argv[1];
    if (argc >= 3) algo     = argv[2];
    if (argc >= 4) {
        quantum = atoi(argv[3]);
        if (quantum <= 0) {
            fprintf(stderr, "Erreur : le quantum doit être un entier > 0.\n");
            return 1;
        }
    }

    Process processes[MAX_PROCESSES];
    int n = load_processes(datafile, processes);

    if (n <= 0) {
        fprintf(stderr,"Aucun processus valide chargé depuis '%s'.\n", datafile);
        return 1;
    }

    printf("Chargement de %d processus depuis '%s'.\n", n, datafile);

    char csv_name[CONFIG_PATH_LEN];
    build_csv_name(config.csv_prefix, algo, csv_name, sizeof(csv_name));

    if (strcmp(algo, "FIFO") == 0) {
        fifo_schedule(processes, n);
        print_metrics(processes, n, "FIFO");
        if (config.save_csv) save_csv(processes, n, "FIFO", csv_name);

    } else if (strcmp(algo, "SJF") == 0) {
        sjf_schedule(processes, n);
        print_metrics(processes, n, "SJF");
        if (config.save_csv) save_csv(processes, n, "SJF", csv_name);

    } else if (strcmp(algo, "RR") == 0) {
        if (argc < 4 && strcmp(config.algo, "RR") != 0) {
            fprintf(stderr,
                "Erreur : RR requiert un quantum.\n"
                "  conf.ini : quantum = 4\n"
                "  CLI : %s data/test.txt RR 4\n", argv[0]);
            return 1;
        }
        rr_schedule(processes, n, quantum);
        print_metrics(processes, n, "RR");
        if (config.save_csv) save_csv(processes, n, "RR", csv_name);

    } else if (strcmp(algo, "SRJF") == 0) {
        srjf_schedule(processes, n);
        print_metrics(processes, n, "SRJF");
        if (config.save_csv) save_csv(processes, n, "SRJF", csv_name);

    } else {
        fprintf(stderr,"Algorithme inconnu : '%s'\n", algo);
        print_usage(argv[0]);
        return 1;
    }

    return 0;
}
