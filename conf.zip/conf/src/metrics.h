/**
 * @file metrics.h
 * @brief Affichage et sauvegarde des résultats de simulation.
 *
 * Indépendant de l'algorithme. Les métriques doivent être calculées
 * avant d'appeler ces fonctions (ordonnancement terminé).
 *
 * @authors Longzhou
 */

#ifndef METRICS_H
#define METRICS_H

#include "process.h"

/**
 * @brief Affiche les résultats sous forme de tableau dans le terminal.
 *
 * @param processes  Tableau de processus après ordonnancement
 * @param n          Nombre de processus
 * @param algo_name  Nom de l'algorithme (ex : "FIFO")
 */
void print_metrics(Process processes[], int n, const char *algo_name);

/**
 * @brief Sauvegarde les résultats dans un fichier CSV (séparateur ';').
 *
 * @param processes  Tableau de processus
 * @param n          Nombre de processus
 * @param algo_name  Nom de l'algorithme
 * @param filename   Chemin du fichier CSV à créer
 */
void save_csv(Process processes[], int n, const char *algo_name, const char *filename);

#endif /* METRICS_H */
