/**
 * @file metrics.c
 * @brief Calcul et affichage des indicateurs de performance.
 *
 * @authors Longzhou
 */

#include <stdio.h>
#include "metrics.h"


/* Taux d'occupation CPU : temps utile / durée totale de simulation, en %. */
static double cpu_utilization(Process processes[], int n)
{
    if (n == 0) return 0.0;

    int total_cpu = 0, first = processes[0].arrival_time, last = 0, i;

    for (i = 0; i < n; i++) {
        total_cpu += processes[i].total_cpu;
        if (processes[i].finish_time   > last)  last  = processes[i].finish_time;
        if (processes[i].arrival_time  < first) first = processes[i].arrival_time;
    }

    int duration = last - first;
    if (duration == 0) return 0.0;

    return (double)total_cpu / duration * 100.0;
}


void print_metrics(Process processes[], int n, const char *algo_name)
{
    double sw = 0, st = 0, sr = 0;
    int i;

    printf("\n=== Résultats : %s ===\n\n", algo_name);
    printf("%-5s %-10s %-7s %-10s %-10s %-12s %-14s %-12s\n", "PID", "Arrivée", "Bursts", "CPU tot", "E/S tot", "Attente", "Restitution", "Réponse");
    printf("--------------------------------------------------------------------------------\n");

    for (i = 0; i < n; i++) {
        Process *p = &processes[i];
        printf("%-5d %-10d %-7d %-10d %-10d %-12d %-14d %-12d\n",
               p->pid, p->arrival_time, p->nb_bursts,
               p->total_cpu, p->total_io,
               p->waiting_time, p->turnaround_time, p->response_time);
        sw += p->waiting_time;
        st += p->turnaround_time;
        sr += p->response_time;
    }

    printf("--------------------------------------------------------------------------------\n");
    printf("Temps d'attente moyen    : %.2f ms\n", sw / n);
    printf("Temps de restitution moy : %.2f ms\n", st / n);
    printf("Temps de réponse moyen   : %.2f ms\n", sr / n);
    printf("Taux d'occupation CPU    : %.2f %%\n",  cpu_utilization(processes, n));
}


void save_csv(Process processes[], int n, const char *algo_name, const char *filename)
{
    double sw = 0, st = 0, sr = 0;
    int i;

    FILE *f = fopen(filename, "w");
    if (!f) { perror("Erreur ouverture fichier CSV"); return; }

    fprintf(f, "Algorithme;PID;Arrivee_ms;Bursts;CPU_tot_ms;ES_tot_ms;Attente_ms;Restitution_ms;Reponse_ms\n");

    for (i = 0; i < n; i++) {
        Process *p = &processes[i];
        fprintf(f, "%s;%d;%d;%d;%d;%d;%d;%d;%d\n",
                algo_name, p->pid, p->arrival_time, p->nb_bursts,
                p->total_cpu, p->total_io,
                p->waiting_time, p->turnaround_time, p->response_time);
        sw += p->waiting_time;
        st += p->turnaround_time;
        sr += p->response_time;
    }

    fprintf(f, "%s;MOYENNE;;;;;%.2f;%.2f;%.2f\n", algo_name, sw / n, st / n, sr / n);
    fprintf(f, "%s;CPU_UTILIZATION;;;;;;%.2f%%\n", algo_name, cpu_utilization(processes, n));


    fclose(f);
    printf("Résultats sauvegardés dans : %s\n", filename);
}
