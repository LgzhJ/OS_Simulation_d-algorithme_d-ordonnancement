/**
 * @file rr.c
 * @brief Round Robin multi-burst.
 *
 * Préemptif, quantum fixe. Le processus retourne en fin de file s'il
 * n'a pas fini son burst. Gestion des E/S : le processus quitte la file
 * pendant l'E/S et revient quand elle se termine.
 *
 * @authors Valentin
 */

#include <stdlib.h>
#include <limits.h>
#include "rr.h"
#include "process.h"

/*
 * File circulaire d'indices de processus.
 *
 * Un processus est toujours dans exactement un de ces états :
 *   - en train de tourner sur le CPU   (1 au maximum)
 *   - dans la file prête               (au plus n - 1)
 *   - bloqué en E/S                    (pas dans la file)
 *   - terminé                          (pas dans la file)
 *
 * → La file ne contient jamais plus de n processus simultanément.
 *   MAX_PROCESSES est donc suffisant ; pas besoin de malloc.
 */
#define RR_QUEUE_CAP MAX_PROCESSES

static void enqueue(int q[], int *tail, int idx)
{
    q[(*tail)++ % RR_QUEUE_CAP] = idx;
}

static int dequeue(int q[], int *head)
{
    return q[(*head)++ % RR_QUEUE_CAP];
}

/* Tri initial par date d'arrivée, puis PID en cas d'égalité */
static int cmp_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    if (pa->arrival_time != pb->arrival_time)
        return pa->arrival_time - pb->arrival_time;
    return pa->pid - pb->pid;
}

/* Enfile tous les processus dont l'E/S vient de se terminer à t */
static void enqueue_io_done(Process processes[], int n,
                             int q[], int *tail, int t)
{
    int i;
    for (i = 0; i < n; i++) {
        if (processes[i].blocked_io && processes[i].io_end_time <= t) {
            process_resume(&processes[i], t);
            enqueue(q, tail, i);
        }
    }
}


void rr_schedule(Process processes[], int n, int quantum)
{
    int i;
    for (i = 0; i < n; i++)
        process_reset(&processes[i]);

    qsort(processes, n, sizeof(Process), cmp_arrival);

    int q[RR_QUEUE_CAP];
    int head     = 0;
    int tail     = 0;
    int t        = 0;   /* horloge courante */
    int done     = 0;
    int next_arr = 0;   /* indice du prochain processus pas encore enfilé */

    /* Enfiler tout ce qui est déjà là au temps 0 */
    while (next_arr < n && processes[next_arr].arrival_time <= t)
        enqueue(q, &tail, next_arr++);

    while (done < n) {

        /* Débloquer les E/S finies + enrôler les nouveaux arrivants */
        enqueue_io_done(processes, n, q, &tail, t);
        while (next_arr < n && processes[next_arr].arrival_time <= t)
            enqueue(q, &tail, next_arr++);

        /* File vide : sauter au prochain événement global */
        if (head == tail) {
            int nxt = process_next_global_event(processes, n, t);
            if (nxt == INT_MAX) break;
            t = nxt;
            continue;
        }

        int idx    = dequeue(q, &head);
        Process *p = &processes[idx];

        process_on_start(p, t);
        int used = process_run(p, quantum);
        t += used;

        /* Récupérer les processus devenus prêts PENDANT la tranche,
         * avant de remettre le processus courant en file */
        enqueue_io_done(processes, n, q, &tail, t);
        while (next_arr < n && processes[next_arr].arrival_time <= t)
            enqueue(q, &tail, next_arr++);

        if (p->cpu_left == 0) {
            process_end_burst(p, t);
            if (process_is_done(p)) {
                done++;                     /* terminé : on l'oublie        */
            } else if (!p->blocked_io) {
                enqueue(q, &tail, idx);    /* prochain burst CPU dispo      */
            }
            /* blocked_io == 1 : enqueue_io_done() le réenfilera plus tard */
        } else {
            enqueue(q, &tail, idx);        /* quantum épuisé, retour en fin de file */
        }
    }
}