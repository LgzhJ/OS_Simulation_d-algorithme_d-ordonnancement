/**
 * @file sjf.h
 * @brief SJF (Shortest Job First).
 *
 * Sélection sur la durée du burst courant. En cas d'égalité :
 * arrival_time, puis PID.
 *
 * @authors Longzhou
 */

#ifndef SJF_H
#define SJF_H

#include "process.h"

/**
 * @brief Lance la simulation SJF.
 *
 * @param processes Tableau de processus
 * @param n Nombre de processus
 */

 /**
 * @brief Simule l'ordonnancement Shortest Job First (SJF) non préemptif
 *
 * Exécute chaque processus prêt ayant le plus court burst CPU jusqu'à sa fin.
 * Si aucun processus n'est prêt, le temps avance jusqu'au prochain événement
 * (arrivée ou fin d'E/S). Met à jour pour chaque processus :
 * - cpu_left, start_time, finish_time
 * - waiting_time, turnaround_time, response_time
 *
 * @note Non préemptif : chaque burst CPU est exécuté complètement.
 *
 * @param processes Tableau de processus
 * @param n Nombre de processus
 */
void sjf_schedule(Process processes[], int n);

#endif
