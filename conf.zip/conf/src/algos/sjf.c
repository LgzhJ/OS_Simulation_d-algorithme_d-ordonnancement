/**
 * @file sjf.c
 * @brief SJF (Shortest Job First).
 *
 * Critères : durée du burst courant, puis arrival_time, puis PID.
 *
 * @authors Longzhou
 */

#include <limits.h>
#include "sjf.h"
#include "process.h"


/* Durée du burst CPU courant d'un processus. */
static int burst_duration(const Process *p){
    return p->bursts[p->current_burst * 2];
}

/* Retourne l'indice du processus courant prêt avec le plus court burst.
 * Retourne -1 si aucun processus n'est prêt. */
static int select_plus_court(Process processes[], int n, int current_time){
    int meilleur_process = -1, i;

    for (i = 0; i < n; i++) {
        if (!process_is_ready(&processes[i], current_time)) {
            continue;
        }  
        if (meilleur_process == -1) { 
            meilleur_process = i; 
            continue; 
        }

        int duree_proc_i = burst_duration(&processes[i]);
        int duree_meilleur_process = burst_duration(&processes[meilleur_process]);

        if (duree_proc_i < duree_meilleur_process) {
            meilleur_process = i;
        
        } else if (duree_proc_i == duree_meilleur_process) {
            if (processes[i].arrival_time < processes[meilleur_process].arrival_time)
                meilleur_process = i;
            
                else if (processes[i].arrival_time == processes[meilleur_process].arrival_time && processes[i].pid < processes[meilleur_process].pid)
                meilleur_process = i;
        }
    }
    return meilleur_process;
}


void sjf_schedule(Process processes[], int n){
    int current_time = 0, done = 0;

    for (int i = 0; i < n; i++){
		process_reset(&processes[i]);
	}

    while (done < n) {

        for (int i = 0; i < n; i++) {
            process_resume(&processes[i], current_time);
        }

        int meilleur_process = select_plus_court(processes, n, current_time);

        if (meilleur_process == -1) {
            int temps_suivant = process_next_global_event(processes, n, current_time);
            if (temps_suivant == INT_MAX) {
                break;
            }
            current_time = temps_suivant;
            continue;
        }

        Process *p = &processes[meilleur_process];
        process_on_start(p, current_time);

        current_time += process_run(p, p->cpu_left); /* burst complet */
        process_end_burst(p, current_time);

        if (process_is_done(p)) {
            done++;
        }
    }
}
