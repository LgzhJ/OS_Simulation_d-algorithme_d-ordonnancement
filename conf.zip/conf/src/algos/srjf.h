/**
 * @file srjf.h
 * @brief SRJF - Shortest Remaining Job First (préemptif).
 *
 * Le processus en cours peut être interrompu si un processus avec un burst restant plus court devient prêt.
 *
 * @authors Mathéo
 */

#ifndef SRJF_H
#define SRJF_H

#include "process.h"

/**
 * @brief Lance la simulation SRJF sur le tableau de processus.
 *
 * @param processes Tableau de processus à ordonnancer
 * @param n Nombre de processus
 */
void srjf_schedule(Process processes[], int n);

#endif
