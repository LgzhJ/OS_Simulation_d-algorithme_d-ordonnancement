/**
 * @file fifo.h
 * @brief Algorithme FIFO (First In, First Out).
 *
 * Non-préemptif : le processus tourne jusqu'à la fin de son burst CPU.
 * Après une E/S il repasse derrière les processus déjà en attente.
 *
 * Critère de sélection : le processus prêt depuis le plus longtemps.
 * Départage sur le PID en cas d'égalité.
 *
 * @authors Mathéo
 */

#ifndef FIFO_H
#define FIFO_H

#include "process.h"

/**
 * @brief Lance la simulation FIFO sur le tableau de processus.
 *
 * Remplit start_time, finish_time, waiting_time, turnaround_time
 * et response_time pour chaque processus.
 *
 * @param processes  Tableau de processus
 * @param n          Nombre de processus
 */
void fifo_schedule(Process processes[], int n);

#endif
