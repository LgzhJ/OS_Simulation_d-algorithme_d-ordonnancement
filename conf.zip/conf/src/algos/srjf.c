/**
 * @file srjf.h
 * @brief SRJF - Shortest Remaining Job First (préemptif).
 *
 * Le processus en cours peut être interrompu si un processus avec un burst restant plus court devient prêt.
 *
 * @authors Mathéo
 */

#include <limits.h>
#include "srjf.h"
#include "process.h"


/*
 * Sélectionne le processus prêt avec le moins de CPU restant (cpu_left).
 * Départage : arrival_time le plus petit, puis PID le plus petit.
 * Retourne -1 si aucun processus n'est prêt.
 */
static int select_shortest_remaining(Process processes[], int n, int current_time) {
    int best_idx = -1;
    int i;

    for (i = 0; i < n; i++) {

        if (!process_is_ready(&processes[i], current_time)) {
            continue;
        }

        if (best_idx == -1) {
            best_idx = i;
            continue;
        }

        int rem_i    = processes[i].cpu_left;
        int rem_best = processes[best_idx].cpu_left;

        if (rem_i < rem_best) {
            best_idx = i;
        } else if (rem_i == rem_best) {
            if (processes[i].arrival_time < processes[best_idx].arrival_time) {
                best_idx = i;
            } else if (processes[i].arrival_time == processes[best_idx].arrival_time && processes[i].pid < processes[best_idx].pid) {
                best_idx = i;
            }
        }
    }

    return best_idx;
}


void srjf_schedule(Process processes[], int n) {
    int i;
    int current_time = 0;
    int nb_done = 0;

    for (i = 0; i < n; i++) {
        process_reset(&processes[i]);
    }

    while (nb_done < n) {

        // Etape 1 : debloquer les processus dont l'E/S est terminee
        for (i = 0; i < n; i++) {
            process_resume(&processes[i], current_time);
        }

        // Etape 2 : choisir le processus avec le moins de CPU restant
        int best_idx = select_shortest_remaining(processes, n, current_time);

        // aucun processus pret : avancer au prochain evenement
        if (best_idx == -1) {
            int next_event = process_next_global_event(processes, n, current_time);
            if (next_event == INT_MAX) {
                break;
            }
            current_time = next_event;
            continue;
        }

        Process *p = &processes[best_idx];

        // Etape 3 : premier demarrage sur le CPU
        process_on_start(p, current_time);

        /*
         * Etape 4 : calculer la durée max avant le prochain point de preemption possible (arrivee ou fin d'E/S).
         * Si aucun evenement prevu, on peut finir le burst entier.
         */
        int next_event = process_next_global_event(processes, n, current_time);
        int max_run;

        if (next_event == INT_MAX) {
            max_run = p->cpu_left;   // pas d'interruption possible
        } else {
            max_run = next_event - current_time;
        }

        int time_used = process_run(p, max_run);
        current_time += time_used;

        // Etape 5 : si le burst est fini, on passe a la suite
        if (p->cpu_left == 0) {
            process_end_burst(p, current_time);
            if (process_is_done(p)) {
                nb_done++;
            }
        }
        // sinon : on a atteint un evenement, on reboucle pour re-selectionner
    }
}
