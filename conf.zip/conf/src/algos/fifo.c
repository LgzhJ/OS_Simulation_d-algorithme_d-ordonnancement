/**
 * @file fifo.c
 * @brief Algorithme FIFO (First In, First Out).
 *
 * Non-préemptif : le processus tourne jusqu'à la fin de son burst CPU.
 * Après une E/S il repasse derrière les processus déjà en attente.
 *
 * Critère de sélection : le processus prêt depuis le plus longtemps.
 * Départage sur le PID en cas d'égalité.
 *
 * @authors Mathéo
 */

#include <limits.h>
#include "fifo.h"
#include "process.h"


/**
 * Renvoie la date à partir de laquelle le processus est prêt :
 *   - premiere fois sur le CPU -> arrival_time
 *   - retour d'une E/S -> io_end_time
 */
static int ready_since(const Process *p) {
    if (!p->has_started) {
        return p->arrival_time;
    }
    return p->io_end_time;
}

/**
 * Parcourt tous les processus et retourne l'indice de celui
 * qui attend depuis le plus longtemps. Retourne -1 si aucun n'est prêt.
 */
static int select_fifo(Process processes[], int n, int current_time) {
    int chosen_idx = -1;
    int i;

    for (i = 0; i < n; i++) {

        if (!process_is_ready(&processes[i], current_time)) {
            continue;
        }

        if (chosen_idx == -1) {
            chosen_idx = i;
            continue;
        }

        int ready_i = ready_since(&processes[i]);
        int ready_chosen = ready_since(&processes[chosen_idx]);

        if (ready_i < ready_chosen) {
            chosen_idx = i;
        } else if (ready_i == ready_chosen) {
            // departage : on prend le plus petit PID
            if (processes[i].pid < processes[chosen_idx].pid) {
                chosen_idx = i;
            }
        }
    }


    return chosen_idx;
}


void fifo_schedule(Process processes[], int n) {
    int i;
    int current_time = 0;
    int nb_done = 0;

    for (i = 0; i < n; i++) {
        process_reset(&processes[i]);
    }

    while (nb_done < n) {

        // debloquer les processus dont l'E/S est terminee
        for (i = 0; i < n; i++) {
            process_resume(&processes[i], current_time);
        }

        // on choisi le prochain processus
        int chosen_idx = select_fifo(processes, n, current_time);

        // Aucun processus pret : on saute au prochain evenement global
        if (chosen_idx == -1) {
            int next_event = process_next_global_event(processes, n, current_time);
            if (next_event == INT_MAX) {
                break;
            }
            current_time = next_event;
            continue;
        }

        Process *p = &processes[chosen_idx];

        // On enregistrer le premier demarrage sur le CPU
        process_on_start(p, current_time);

        // executer le burst en entier
        int time_used = process_run(p, p->cpu_left);
        current_time += time_used;

        // fin du cycle CPU
        process_end_burst(p, current_time);

        if (process_is_done(p)) {
            nb_done++;
        }
    }
}
