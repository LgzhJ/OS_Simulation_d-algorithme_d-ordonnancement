/**
 * @file rr.h
 * @brief Round Robin (RR) - préemptif, quantum fixe.
 *
 * @authors Valentin
 */

#ifndef RR_H
#define RR_H

#include "process.h"

// Lance la simulation Round Robin.
// quantum : durée max d'une tranche CPU en ms (doit être > 0)
void rr_schedule(Process processes[], int n, int quantum);

#endif
